# Food-Donation-App
This is a food donation app. User donate food through this app and volunteer will collect this food see information from app. And volunteer serve this food to helpless peoples.

<h2> Used Component </h2>
<hr>
-RecyclerView And CardView<br>
-Room Database<br>
-Firebase<br>
-AndroidX<br>
-Used language Java

<h2> Project Screen Shot
  <h4> first page </h4>
<img src = "https://user-images.githubusercontent.com/48477320/69885768-f5a32f80-1308-11ea-998a-96f6d4ea3a18.PNG" />
  <hr>
  <h4> Donator Information Page </h4>
  <img src = "https://user-images.githubusercontent.com/48477320/69886470-4ff1bf80-130c-11ea-966f-236619584102.PNG" />
  <hr>
  <h4> Donation Information Page </h4>
  <img src = "https://user-images.githubusercontent.com/48477320/69886507-70217e80-130c-11ea-8913-ec99a062a6c0.PNG" />
